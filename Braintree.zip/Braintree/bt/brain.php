<?php
require_once 'lib/Braintree.php';
Braintree_Configuration::environment('sandbox');
Braintree_Configuration::merchantId('k4p57kc2t3xjjhy2');
Braintree_Configuration::publicKey('7m5w56rj2jw6ryjp');
Braintree_Configuration::privateKey('6389483abf88f888cfed9072b1ca3a97');
$result = Braintree_Transaction::sale(array(
    'amount' => '400',
    'orderId' => '220' , 
    'creditCard' => array(
        'number' =>  '4111111111111111',
        'expirationDate' =>'04/16',
        'cardholderName' =>'Ritesh',
    )
));
if ($result->success) {
    echo "Transaction done successfully";
	header("location:http://www.google.com");
}
else if ($result->transaction) 
{
   $msg .= "Error processing transaction:<br>" ;
   $msg .="\n  code: " . $result->transaction->processorResponseCode ;
   $msg .="\n  text: " . $result->transaction->processorResponseText ;
   echo $msg ; 
} 
?>